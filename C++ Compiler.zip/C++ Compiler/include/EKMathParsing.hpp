#ifndef EKMath
#define EKMath
#include <iostream>
#include <string>
#include <deque>
#include <stack>
#include <algorithm>
#include "Exceptions.hpp"
using namespace error;

namespace math{
class MathParse{
    private:
    public:
        std::string Parse(std::string);
};
}

#endif 